import React from 'react';

const AppLayout: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      <header className="bg-blue-600 text-white p-4">
        <h1 className="text-2xl font-bold">Smart Inventory Manager</h1>
      </header>
      <main className="p-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-xl mb-4">Welcome to your inventory manager</h2>
          <p className="text-gray-600">Organize, sell, or donate your possessions with ease.</p>
        </div>
      </main>
    </div>
  );
};

export default AppLayout;